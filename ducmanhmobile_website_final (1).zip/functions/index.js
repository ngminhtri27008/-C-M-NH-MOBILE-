const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { initializeApp } = require("firebase-admin/app");
const { getAuth } = require("firebase-admin/auth");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");

initializeApp();

exports.createStaffAccount = onCall({ region: "asia-southeast1" }, async (request) => {
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "Bạn cần đăng nhập.");
  }

  const db = getFirestore();
  const caller = await db.collection("users").doc(request.auth.uid).get();
  if (!caller.exists || caller.data().role !== "admin") {
    throw new HttpsError("permission-denied", "Chỉ quản trị viên mới được tạo nhân viên.");
  }

  const email = String(request.data?.email || "").trim().toLowerCase();
  const password = String(request.data?.password || "");
  if (!/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(email) || password.length < 8) {
    throw new HttpsError("invalid-argument", "Email không hợp lệ hoặc mật khẩu dưới 8 ký tự.");
  }

  let createdUser;
  try {
    createdUser = await getAuth().createUser({ email, password, emailVerified: false });
    await db.collection("users").doc(createdUser.uid).create({
      email,
      role: "staff",
      createdAt: FieldValue.serverTimestamp(),
      createdBy: request.auth.uid
    });
    return { uid: createdUser.uid, email };
  } catch (error) {
    if (createdUser?.uid) {
      await getAuth().deleteUser(createdUser.uid).catch(() => {});
    }
    if (error.code === "auth/email-already-exists") {
      throw new HttpsError("already-exists", "Email này đã có tài khoản.");
    }
    console.error("createStaffAccount failed:", error);
    throw new HttpsError("internal", "Không thể tạo tài khoản nhân viên.");
  }
});
